<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Welcome to YBP</title>
<link href="css_yb_standard.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
.style8 {font-style: italic; font-size: 18px;}
.style9 {font-size: 16px}
-->
</style>

<script type="text/javascript">
function load()
{
 alert ("asdsds")
}
</script>
</head>

<body class="yb_standard">
<table width="760" border="0" align="center" cellpadding="1" cellspacing="0">
  <tr>
    <td><p class="yb_heading2">Before signing in - Please help us out by taking a short YBP survey</p>
      <ul>
        <li>You answers will help us gauge our effectiveness, apply for funding, and make Yellow Bike a better community resource.</li>
        <li>This survey is intended for anyone who has been involved with YBP  through volunteering, fixing a bicycle, or learning about bikes. </li>
        <li>To skip survey and go to sign-in click on one of the following: <br />
&nbsp;&nbsp;&nbsp;&nbsp;<a href="shop_log.php">Just Completed Survey</a> | <a href="shop_log.php">Previously Completed Survey</a> | <a href="shop_log.php">Take it Later</a> | <a href="shop_log.php">Do Not Wish to Take</a> </li>
      </ul>
      <span class="yb_heading2">YBP Survey:      </span>
      <IFRAME src ="http://www.surveyartisan.com/startsurvey.php?surveyid=9010f36293d49bd66c3007137af65c7d" frameborder=0 height=3000 scrolling="no" width="100%" onload="parent.scrollTo(0,0)"></IFRAME>      </td>
  </tr>
</table>
</body>
</html>
