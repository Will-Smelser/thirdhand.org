<?php
# FileName="Connection_php_mysql.htm"
# Type="MYSQL"
# HTTP="true"
$hostname_YBDB = "mysql.ybdb.austinyellowbike.org";
$database_YBDB = "ybdb";
$username_YBDB = "admin";
$password_YBDB = "yblcatx";
$YBDB = mysql_pconnect($hostname_YBDB, $username_YBDB, $password_YBDB) or trigger_error(mysql_error(),E_USER_ERROR); 
?>